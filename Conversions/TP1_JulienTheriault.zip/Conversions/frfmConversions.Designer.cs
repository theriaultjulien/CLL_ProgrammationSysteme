﻿namespace Conversions
{
    partial class frfmConversions
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtBinDeHexa = new System.Windows.Forms.TextBox();
            this.txtHexaABin = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.txtBinAHexa = new System.Windows.Forms.TextBox();
            this.txtHexaDeDec = new System.Windows.Forms.TextBox();
            this.txtDecimalAHexa = new System.Windows.Forms.TextBox();
            this.txtDecimalDeHexa = new System.Windows.Forms.TextBox();
            this.txtHexaADec = new System.Windows.Forms.TextBox();
            this.txtBinaireDeDec = new System.Windows.Forms.TextBox();
            this.txtDecimalABin = new System.Windows.Forms.TextBox();
            this.txtDecimalDeBin = new System.Windows.Forms.TextBox();
            this.txtBinaireADec = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnHexaBin = new System.Windows.Forms.Button();
            this.btnBinHexa = new System.Windows.Forms.Button();
            this.btnDecHexa = new System.Windows.Forms.Button();
            this.btnHexaDec = new System.Windows.Forms.Button();
            this.btnDecBin = new System.Windows.Forms.Button();
            this.btnBinaireDecimal = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtBinDeHexa
            // 
            this.txtBinDeHexa.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBinDeHexa.Location = new System.Drawing.Point(437, 382);
            this.txtBinDeHexa.Margin = new System.Windows.Forms.Padding(4);
            this.txtBinDeHexa.Name = "txtBinDeHexa";
            this.txtBinDeHexa.Size = new System.Drawing.Size(159, 26);
            this.txtBinDeHexa.TabIndex = 59;
            // 
            // txtHexaABin
            // 
            this.txtHexaABin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHexaABin.Location = new System.Drawing.Point(47, 382);
            this.txtHexaABin.Margin = new System.Windows.Forms.Padding(4);
            this.txtHexaABin.Name = "txtHexaABin";
            this.txtHexaABin.Size = new System.Drawing.Size(160, 26);
            this.txtHexaABin.TabIndex = 58;
            // 
            // textBox10
            // 
            this.textBox10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox10.Location = new System.Drawing.Point(437, 314);
            this.textBox10.Margin = new System.Windows.Forms.Padding(4);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(159, 26);
            this.textBox10.TabIndex = 57;
            // 
            // txtBinAHexa
            // 
            this.txtBinAHexa.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBinAHexa.Location = new System.Drawing.Point(47, 314);
            this.txtBinAHexa.Margin = new System.Windows.Forms.Padding(4);
            this.txtBinAHexa.Name = "txtBinAHexa";
            this.txtBinAHexa.Size = new System.Drawing.Size(160, 26);
            this.txtBinAHexa.TabIndex = 56;
            // 
            // txtHexaDeDec
            // 
            this.txtHexaDeDec.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHexaDeDec.Location = new System.Drawing.Point(437, 247);
            this.txtHexaDeDec.Margin = new System.Windows.Forms.Padding(4);
            this.txtHexaDeDec.Name = "txtHexaDeDec";
            this.txtHexaDeDec.Size = new System.Drawing.Size(159, 26);
            this.txtHexaDeDec.TabIndex = 55;
            // 
            // txtDecimalAHexa
            // 
            this.txtDecimalAHexa.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDecimalAHexa.Location = new System.Drawing.Point(47, 247);
            this.txtDecimalAHexa.Margin = new System.Windows.Forms.Padding(4);
            this.txtDecimalAHexa.Name = "txtDecimalAHexa";
            this.txtDecimalAHexa.Size = new System.Drawing.Size(160, 26);
            this.txtDecimalAHexa.TabIndex = 54;
            // 
            // txtDecimalDeHexa
            // 
            this.txtDecimalDeHexa.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDecimalDeHexa.Location = new System.Drawing.Point(437, 186);
            this.txtDecimalDeHexa.Margin = new System.Windows.Forms.Padding(4);
            this.txtDecimalDeHexa.Name = "txtDecimalDeHexa";
            this.txtDecimalDeHexa.Size = new System.Drawing.Size(159, 26);
            this.txtDecimalDeHexa.TabIndex = 53;
            // 
            // txtHexaADec
            // 
            this.txtHexaADec.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHexaADec.Location = new System.Drawing.Point(47, 187);
            this.txtHexaADec.Margin = new System.Windows.Forms.Padding(4);
            this.txtHexaADec.Name = "txtHexaADec";
            this.txtHexaADec.Size = new System.Drawing.Size(160, 26);
            this.txtHexaADec.TabIndex = 52;
            // 
            // txtBinaireDeDec
            // 
            this.txtBinaireDeDec.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBinaireDeDec.Location = new System.Drawing.Point(437, 114);
            this.txtBinaireDeDec.Margin = new System.Windows.Forms.Padding(4);
            this.txtBinaireDeDec.Name = "txtBinaireDeDec";
            this.txtBinaireDeDec.Size = new System.Drawing.Size(159, 26);
            this.txtBinaireDeDec.TabIndex = 51;
            // 
            // txtDecimalABin
            // 
            this.txtDecimalABin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDecimalABin.Location = new System.Drawing.Point(47, 114);
            this.txtDecimalABin.Margin = new System.Windows.Forms.Padding(4);
            this.txtDecimalABin.Name = "txtDecimalABin";
            this.txtDecimalABin.Size = new System.Drawing.Size(160, 26);
            this.txtDecimalABin.TabIndex = 50;
            // 
            // txtDecimalDeBin
            // 
            this.txtDecimalDeBin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDecimalDeBin.Location = new System.Drawing.Point(437, 50);
            this.txtDecimalDeBin.Margin = new System.Windows.Forms.Padding(4);
            this.txtDecimalDeBin.Name = "txtDecimalDeBin";
            this.txtDecimalDeBin.Size = new System.Drawing.Size(159, 26);
            this.txtDecimalDeBin.TabIndex = 49;
            // 
            // txtBinaireADec
            // 
            this.txtBinaireADec.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBinaireADec.Location = new System.Drawing.Point(47, 46);
            this.txtBinaireADec.Margin = new System.Windows.Forms.Padding(4);
            this.txtBinaireADec.Name = "txtBinaireADec";
            this.txtBinaireADec.Size = new System.Drawing.Size(160, 26);
            this.txtBinaireADec.TabIndex = 48;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(431, 292);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(111, 20);
            this.label12.TabIndex = 47;
            this.label12.Text = "Hexadécimal";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(42, 292);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(65, 20);
            this.label11.TabIndex = 46;
            this.label11.Text = "Binaire";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(433, 359);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(65, 20);
            this.label10.TabIndex = 45;
            this.label10.Text = "Binaire";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(42, 357);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(111, 20);
            this.label9.TabIndex = 44;
            this.label9.Text = "Hexadécimal";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(42, 224);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(73, 20);
            this.label8.TabIndex = 43;
            this.label8.Text = "Décimal";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(431, 224);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(111, 20);
            this.label7.TabIndex = 42;
            this.label7.Text = "Hexadécimal";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(42, 158);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(111, 20);
            this.label6.TabIndex = 41;
            this.label6.Text = "Hexadécimal";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(433, 162);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(73, 20);
            this.label5.TabIndex = 40;
            this.label5.Text = "Décimal";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(431, 91);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 20);
            this.label4.TabIndex = 39;
            this.label4.Text = "Binaire";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(42, 91);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 20);
            this.label3.TabIndex = 38;
            this.label3.Text = "Décimal";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(431, 21);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 20);
            this.label2.TabIndex = 37;
            this.label2.Text = "Décimal";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(42, 21);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 20);
            this.label1.TabIndex = 36;
            this.label1.Text = "Binaire";
            // 
            // btnHexaBin
            // 
            this.btnHexaBin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHexaBin.Location = new System.Drawing.Point(258, 380);
            this.btnHexaBin.Margin = new System.Windows.Forms.Padding(4);
            this.btnHexaBin.Name = "btnHexaBin";
            this.btnHexaBin.Size = new System.Drawing.Size(112, 28);
            this.btnHexaBin.TabIndex = 35;
            this.btnHexaBin.Text = "-->";
            this.btnHexaBin.UseVisualStyleBackColor = true;
            this.btnHexaBin.Click += new System.EventHandler(this.btnHexaBin_Click);
            // 
            // btnBinHexa
            // 
            this.btnBinHexa.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBinHexa.Location = new System.Drawing.Point(258, 312);
            this.btnBinHexa.Margin = new System.Windows.Forms.Padding(4);
            this.btnBinHexa.Name = "btnBinHexa";
            this.btnBinHexa.Size = new System.Drawing.Size(112, 28);
            this.btnBinHexa.TabIndex = 34;
            this.btnBinHexa.Text = "-->";
            this.btnBinHexa.UseVisualStyleBackColor = true;
            this.btnBinHexa.Click += new System.EventHandler(this.btnBinHexa_Click);
            // 
            // btnDecHexa
            // 
            this.btnDecHexa.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDecHexa.Location = new System.Drawing.Point(258, 245);
            this.btnDecHexa.Margin = new System.Windows.Forms.Padding(4);
            this.btnDecHexa.Name = "btnDecHexa";
            this.btnDecHexa.Size = new System.Drawing.Size(112, 28);
            this.btnDecHexa.TabIndex = 33;
            this.btnDecHexa.Text = "-->";
            this.btnDecHexa.UseVisualStyleBackColor = true;
            this.btnDecHexa.Click += new System.EventHandler(this.btnDecHexa_Click);
            // 
            // btnHexaDec
            // 
            this.btnHexaDec.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHexaDec.Location = new System.Drawing.Point(258, 184);
            this.btnHexaDec.Margin = new System.Windows.Forms.Padding(4);
            this.btnHexaDec.Name = "btnHexaDec";
            this.btnHexaDec.Size = new System.Drawing.Size(112, 28);
            this.btnHexaDec.TabIndex = 32;
            this.btnHexaDec.Text = "-->";
            this.btnHexaDec.UseVisualStyleBackColor = true;
            this.btnHexaDec.Click += new System.EventHandler(this.btnHexaDec_Click);
            // 
            // btnDecBin
            // 
            this.btnDecBin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDecBin.Location = new System.Drawing.Point(258, 112);
            this.btnDecBin.Margin = new System.Windows.Forms.Padding(4);
            this.btnDecBin.Name = "btnDecBin";
            this.btnDecBin.Size = new System.Drawing.Size(112, 28);
            this.btnDecBin.TabIndex = 31;
            this.btnDecBin.Text = "-->";
            this.btnDecBin.UseVisualStyleBackColor = true;
            this.btnDecBin.Click += new System.EventHandler(this.btnDecBin_Click);
            // 
            // btnBinaireDecimal
            // 
            this.btnBinaireDecimal.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBinaireDecimal.Location = new System.Drawing.Point(258, 46);
            this.btnBinaireDecimal.Margin = new System.Windows.Forms.Padding(4);
            this.btnBinaireDecimal.Name = "btnBinaireDecimal";
            this.btnBinaireDecimal.Size = new System.Drawing.Size(112, 28);
            this.btnBinaireDecimal.TabIndex = 30;
            this.btnBinaireDecimal.Text = "-->";
            this.btnBinaireDecimal.UseVisualStyleBackColor = true;
            this.btnBinaireDecimal.Click += new System.EventHandler(this.btnBinaireDecimal_Click);
            // 
            // frfmConversions
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(655, 450);
            this.Controls.Add(this.txtBinDeHexa);
            this.Controls.Add(this.txtHexaABin);
            this.Controls.Add(this.textBox10);
            this.Controls.Add(this.txtBinAHexa);
            this.Controls.Add(this.txtHexaDeDec);
            this.Controls.Add(this.txtDecimalAHexa);
            this.Controls.Add(this.txtDecimalDeHexa);
            this.Controls.Add(this.txtHexaADec);
            this.Controls.Add(this.txtBinaireDeDec);
            this.Controls.Add(this.txtDecimalABin);
            this.Controls.Add(this.txtDecimalDeBin);
            this.Controls.Add(this.txtBinaireADec);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnHexaBin);
            this.Controls.Add(this.btnBinHexa);
            this.Controls.Add(this.btnDecHexa);
            this.Controls.Add(this.btnHexaDec);
            this.Controls.Add(this.btnDecBin);
            this.Controls.Add(this.btnBinaireDecimal);
            this.Name = "frfmConversions";
            this.Text = "Les conversions";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtBinDeHexa;
        private System.Windows.Forms.TextBox txtHexaABin;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox txtBinAHexa;
        private System.Windows.Forms.TextBox txtHexaDeDec;
        private System.Windows.Forms.TextBox txtDecimalAHexa;
        private System.Windows.Forms.TextBox txtDecimalDeHexa;
        private System.Windows.Forms.TextBox txtHexaADec;
        private System.Windows.Forms.TextBox txtBinaireDeDec;
        private System.Windows.Forms.TextBox txtDecimalABin;
        private System.Windows.Forms.TextBox txtDecimalDeBin;
        private System.Windows.Forms.TextBox txtBinaireADec;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnHexaBin;
        private System.Windows.Forms.Button btnBinHexa;
        private System.Windows.Forms.Button btnDecHexa;
        private System.Windows.Forms.Button btnHexaDec;
        private System.Windows.Forms.Button btnDecBin;
        private System.Windows.Forms.Button btnBinaireDecimal;
    }
}

